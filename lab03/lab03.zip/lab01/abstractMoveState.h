#pragma once
#include "Library.h"

class abstractMoveState
{
public:
	abstractMoveState(std::shared_ptr<sf::Vector2f> t_position)
	{
		m_position = t_position;
	}
	virtual void init(){ }

	virtual sf::Vector2f moveVector(sf::Vector2f t_playerPos, float t_playerAngle, float t_speed) = 0;
	virtual sf::Vector2f moveWithLocal(std::vector<sf::Vector2f> t_others) { return sf::Vector2f(); }


	sf::Angle getAngle()
	{
		return sf::degrees(m_angle + 90.0f);
	}

	void changeMaxSpeed(float newMax)
	{
		m_maxSpeed = newMax;
	}
	void changeSpeed(float newMax)
	{
		m_speed = newMax;
	}
protected:
	void increaseSpeed();
	void decreaseSpeed();
	void changeAngle(int t_direction);

	float m_angle = 0.0f;
	float m_angleChange = 50.0f;

	float m_speed = 200.0f;
	float m_maxSpeed = 300.0f;
	float m_speedIncreaseFactor = 100.0f;
	std::shared_ptr<sf::Vector2f> m_position;
};
